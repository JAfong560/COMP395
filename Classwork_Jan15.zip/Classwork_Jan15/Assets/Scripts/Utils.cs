﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public static class Utils
{
    //MSE - Mean Square Error
    public static void LinReg(double[] x, double[] y, out double A, out double B, out double MSE){
        double sx = 0;
        double sy = 0;
        double sxx = 0;
        double sxy = 0;
        MSE = 0;
        int n = x.Length;
        for(int i = 0; i < n; i++)
        {
            sx += x[i];
            sy += y[i];
            sxy += x[i] * y[i];
            sxx += x[i] * x[i];
        }

        B = (n * sxy - sx * sy) / (n * sxx - sx * sx);
        A = (sy - B * sx) / n;

        for(int i = 0; i < n; i++)
        {
            double e = (y[i] - A - B * x[i]);
            MSE += e * e;
        }
    }
}
