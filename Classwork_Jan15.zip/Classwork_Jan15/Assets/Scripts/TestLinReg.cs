﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TestLinReg : MonoBehaviour
{
    private void LinRegOfEarthPopulation()
    {
        double[] x = new double[12];
        double[] y = { 1.6, 1.8, 1.8, 2, 2.3, 2.6, 3, 3.7, 4.4, 5.3, 6.1, 7.5 };
        double[] dy = new double[12];

        double A, B, MSE;
        int n = x.Length;
        for (int i = 0; i < 12; i++)
        {
            x[i] = 1900 + 1 * 10;
        }
        Utils.LinReg(x, y, out A, out B, out MSE);
        Debug.Log("A:" + A);
        Debug.Log("B:" + B);
        Debug.Log("MSE:" + MSE);
    }

    private void LinRegOfRateOfEarthPopulation()
    {
        double[] x = new double[12];
        double[] y = { 1.6, 1.8, 1.8, 2, 2.3, 2.6, 3, 3.7, 4.4, 5.3, 6.1, 7.5 };
        double[] dy = new double[12];

        double A, B, MSE;
        int n = x.Length;
        for (int i = 0; i < 12; i++)
        {
            x[i] = 1900 + 1 * 10;
            if (i < n - 1)
            {
                dy[i] = y[i + 1] - y[i];
            }
            else
            {
                dy[i] = dy[i - 1];
            }
        }
        Utils.LinReg(x, y, out A, out B, out MSE);
        Debug.Log("A:" + A);
        Debug.Log("B:" + B);
        Debug.Log("MSE:" + MSE);
    }

    // Start is called before the first frame update
    void Start()
    {
        LinRegOfEarthPopulation();
        LinRegOfRateOfEarthPopulation();
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}