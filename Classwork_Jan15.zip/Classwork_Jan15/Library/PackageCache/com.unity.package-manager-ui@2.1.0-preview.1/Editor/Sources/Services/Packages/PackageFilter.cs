﻿using System;

namespace UnityEditor.PackageManager.UI
{
    [Serializable]
    internal enum PackageFilter
    {
        All,
        Local,
        Modules
    }
}